<div class="col-12 mb-4">
    <a type="button" class="btn btn-outline-dark" href="{{ url()->previous() }}">Go Back</a>
</div>
<div class="jumbotron">
    <h1 class="display-4">Sorry, No Posts!</h1>
    <p class="lead">We couldn't find the post you're looking for.</p>
    <hr class="my-4">
    <p class="lead">
        <a class="btn btn-outline-primary" href="{{ route('user.posts.create') }}" role="button">
            Click here to start adding posts.
        </a>
    </p>
</div>

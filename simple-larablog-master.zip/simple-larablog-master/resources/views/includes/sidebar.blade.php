<!-- Sidebar Widgets Column -->
<div class="col-md-4">

    @include('partials.search-form-widget')

    @include('partials.category-widget')

</div>
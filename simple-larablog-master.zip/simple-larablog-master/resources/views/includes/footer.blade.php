<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">
            Copyright &copy; {{ config('app.name', 'Larablog') }} {{ now()->year }} 
            | <a href="https://laravelproject.com">https://laravelproject.com</a>
        </p>
    </div>
    <!-- /.container -->
</footer>